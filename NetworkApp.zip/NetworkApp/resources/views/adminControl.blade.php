@extends('layouts.app')
@section('title', 'User table Page')

@section('content')
<!-- Styles are here to override boostrap css -->
<style>
<!--
.table {

   width: auto;
}

.table th {
  height: 50px;
  font-size: 12px;
  padding: 15px;
 width: 150px;
 text-align: left;

}
.table td {
  height: 50px;
  font-size: 12px;
  padding-left: 30px;
 width: 20%;

 font-weight: bold;

}
-->
</style>
  	<div>
  		<div class="table-responsive bg-light">
  		<table class="table" style="color: black">
  				<tr style="display:inline-flex;">
  					<th class="center" >Email</th>
  					<th class="center" >First Name</th>
  					<th class="center">Last Name</th>
  					<th class="center" >Phone Number</th>
  					<th class="center" >Role</th>	
  				</tr>
  			</table>
  		@foreach ($model as $user)
  		@if($user->getId() != Session::get('users_id'))
  			<table class="table" style="color: black">
  				<tr style="text-align: center">
  					<td>{{$user->getEmail()}}</td>
  					<td>{{$user->getFirstname()}}</td>
  					<td>{{$user->getLastname()}}</td> 		
  					<td>{{$user->getPhonenumber()}}</td>				
  					<td>{{$user->getRole()}}</td>
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px" href="{{ route('profileEdit', $user->getId()) }}">Edit Profile</a></td>
  					@if($user->getSuspend() == 0)
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="{{URL::to('/suspendUser/'.$user->getId()) }}">Suspend</a></td>
  					@elseif($user->getSuspend() == 1)
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="{{URL::to('/unSuspendUser/'.$user->getId()) }}">UnSuspend</a></td>
  					@endif
  					<td><a class="btn btn-primary bold confirm" style="width: 80px; height: 25px; font-size: 10px"  href="{{URL::to('/terminateUser/'.$user->getId()) }}">Delete</a></td>
  				</tr>
  			</table>
  			@endif
  		@endforeach
  		</div>
  	</div>
 
    <script type="text/javascript">
    $(function() {
        $('.confirm').click(function() {
            return window.confirm("Are you sure?");
        });
    });
    </script>
@endsection