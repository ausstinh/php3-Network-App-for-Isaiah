@extends('layouts.app')
@section('title', 'User table Page')

@section('content')
<style>
<!--
.table {

   width: auto;
}

.table th {
  height: 50px;
  font-size: 12px;
  padding: 15px;
 width: 150px;
 text-align: left;

}
.table td {
  height: 50px;
  font-size: 12px;
  padding-left: 30px;
 width: 20%;

 font-weight: bold;

}
-->
</style>
  	<div class="main-body-content w-100">
  		<div class="table-responsive bg-light">
  		<table class="table" style="color: black">
  				<tr>
  					<th>Email</th>
  					<th>First Name</th>
  					<th>Last Name</th>
  					<th>Company</th>
  					<th>Phone Number</th>
  				</tr>
  			</table>
  		@foreach ($model as $user)
  		@if($user->getId() != Session::get('users_id'))
  			<table class="table" style="color: black">
  				<tr>
  					<th>{{$user->getEmail()}}</th>
  					<th>{{$user->getFirstname()}}</th>
  					<th>{{$user->getLastname()}}</th> 		
  					<th>{{$user->getCompany()}}</th>
  					<th>{{$user->getPhonenumber()}}</th>								>
  					<th><a class="btn btn-primary bold" href="{{ route('profileEdit', $user->getId()) }}">Edit Profile</a></th>					
  				</tr>
  			</table>
  			@endif
  		@endforeach
  		</div>
  	</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
    <script type="text/javascript">
    $(function() {
        $('.confirm').click(function() {
            return window.confirm("Are you sure?");
        });
    });
    </script>
@endsection