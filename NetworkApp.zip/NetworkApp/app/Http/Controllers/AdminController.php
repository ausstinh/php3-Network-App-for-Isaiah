<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Logging\Log;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Services\Business\UserBusinessService;
use App\Models\UserModel;
class AdminController extends Controller
{
    /**
     * Takes in a new user
     * Calls the business service to register
     * If successful, return the login form
     * If not, return the register form
     *
     * @param newUser	user to register
     * @return login view page
     */
    public function getUsersTable(Request $request)
    {
       
        //new instance of business service
        $userBS = new UserBusinessService();
        //create new user and with variables holding user input
        $users = $userBS->getAllUsers();
        //if statement checking if createNewUser returns true
        if($users)
        {
            $data = ['model' => $users];
            if(session('role') == 2)
                return view("adminControl")->with($data);
            else
            //if true, return login view
            return view("usertable")->with($data);
        }
        else{
            $user = session('user');
            $data = ['model'=> $user];
            //if false, re-return register page so user can try again
            return view("home")->with($user);
        }
        
    }
    public function terminateUser($users_id)
    {
        
        //new instance of business service
        $userBS = new UserBusinessService();
        //create new user and with variables holding user input
        $user = $userBS->terminateUser($users_id);
        //if statement checking if createNewUser returns true
        if($user)
        {
            if(session('role') == 2)
                return Redirect::route('admincontrol');
                else
                    //if true, return login view
                    return Redirect::route('usertable');
        }
        else{
            $user = session('user');
            $data = ['model'=> $user];
            //if false, re-return register page so user can try again
            return view("home")->with($data);
        }
    }
        public function suspendUser($users_id)
        {
            
            //new instance of business service
            $userBS = new UserBusinessService();
            //create new user and with variables holding user input
            $user = $userBS->suspendUser($users_id);
            //if statement checking if createNewUser returns true
            if($user)
            {
                if(session('role') == 2)
                    return Redirect::route('admincontrol');
                    else
                        //if true, return login view
                        return Redirect::route('usertable');
            }
            else{
                $user = session('user');
                $data = ['model'=> $user];
                //if false, re-return register page so user can try again
                return view("home")->with($data);
            }
         }
         
         public function unSuspendUser($users_id)
         {
             
             //new instance of business service
             $userBS = new UserBusinessService();
             //create new user and with variables holding user input
             $users = $userBS->unSuspendUser($users_id);
             //if statement checking if createNewUser returns true
             if($users)
             {
                 if(session('role') == 2)
                     return Redirect::route('admincontrol');
                     else
                         //if true, return login view
                         return Redirect::route('usertable');
             }
             else{
                 $user = session('user');
                 $data = ['model'=> $user];
                 //if false, re-return register page so user can try again
                 return view("home")->with($data);
             }
         }
    
}
