<?php
use App\Models\UserModel;
?>

<?php $__env->startSection('title', 'Profile'); ?> 
<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <body>
       <div class="container emp-profile">
       
                <div class="row">
                    <div class="col-md-4">
                    <!-- In case we want to add profile photos -->
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">  
                           <!-- In case we want to put somthing in the profile header -->                                                                   
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a class="btn btn-primary bold" href="<?php echo e(route('profileEdit', $model->getId())); ?>">Edit Profile</a>
                    </div>
                </div>
                <div class="row">                  
                    <div class="col-md-6">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active center" id="home" role="tabpanel" aria-labelledby="home-tab">
                                          <div class="row">
                                            <div class="col-md-3 " style="color:Black">
                                                <label hidden>ID</label>
                                            </div>
                                            <div class="col-md-5 ">
                                                <p hidden><?php echo e($model->getId()); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3 " style="color:Black">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-5 ">
                                                <p><?php echo e($model->getEmail()); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-5">
                                                <p><?php echo e($model->getFirstName()); ?> <?php echo e($model->getLastName()); ?></p>
                                            </div>
                                        </div>                                   
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Phone</label>
                                            </div>
                                            <?php if($model->getPhonenumber() != null): ?>
                                            <div class="col-md-5">
                                                <p><?php echo e($model->getPhonenumber()); ?></p>
                                            </div>
                                            <?php else: ?>
                                             <div class="col-md-5">
                                                <p>No Phone Number yet!</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Company</label>
                                            </div>
                                           <?php if($model->getCompany() != null): ?>
                                            <div class="col-md-5">
                                                <p><?php echo e($model->getCompany()); ?></p>
                                            </div>
                                            <?php else: ?>
                                            <div class="col-md-5">
                                                <p>No Company Yet!</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Website</label>
                                            </div>
                                           <?php if($model->getWebsite() != null): ?>
                                            <div class="col-md-5">
                                                <p><?php echo e($model->getWebsite()); ?></p>
                                            </div>
                                            <?php else: ?>
                                            <div class="col-md-5">
                                                <p>No Website Yet!</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                            </div>
                        </div>
                    </div>
                      <div class="col-md-6">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active center" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-3 " style="color:Black">
                                                <label>Birth Date</label>
                                            </div>
                                            <?php if($model->getBirthdate() != null): ?>
                                            <div class="col-md-5 ">
                                                <p><?php echo e($model->getBirthdate()); ?></p>
                                            </div>
                                            <?php else: ?>
                                             <div class="col-md-5 ">
                                                <p>No Birthdate Yet!</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Gender</label>
                                            </div>
                                            <?php if($model->getGender() == 0): ?>
                                            <div class="col-md-5">
                                                <p>Male</p>
                                            </div>
                                            <?php else: ?>
                                             <div class="col-md-5">
                                                <p>Female</p>
                                            </div>
                                            <?php endif; ?>
                                        </div>                                   
                                        <div class="row">
                                            <div class="col-md-3" style="color:Black">
                                                <label>Bio</label>
                                            </div>
                                           <?php if($model->getBio() != null): ?>
                                            <div class="col-md-5">
                                                <p><?php echo e($model->getBio()); ?></p>
                                            </div>
                                            <?php else: ?>
                                              <div class="col-md-5">
                                                <p>No Bio Yet!</p>
                                            </div>
                                            <?php endif; ?>
                                    </div>                                      
                            </div>
                        </div>
                    </div>
                </div>         
        </div>     
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>