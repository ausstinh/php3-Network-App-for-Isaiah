 	
<?php $__env->startSection('title', 'Home'); ?> 

<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<div class="flex-center position-ref full-height">
	<div class="content" style="padding-bottom: 300px">
		<div class="title m-b-md"></div>
		<h2 style="font-weight: 700">Welcome <?php echo e($model->getFirstName()); ?> <?php echo e($model->getLastName()); ?></h2><br>
		<h2 style="font-weight: 700">Style your Profile!</h2>
		
	</div>
</div>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>