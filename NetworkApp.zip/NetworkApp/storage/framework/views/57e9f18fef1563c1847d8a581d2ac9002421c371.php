<?php $__env->startSection('title', 'User table Page'); ?>

<?php $__env->startSection('content'); ?>

  	<div class="main-body-content w-100">
  		<div class="table-responsive bg-light">
  		<table class="table" style="color: black">
  				<tr>
  					<th>Email</th>
  					<th>First Name</th>
  					<th>Last Name</th>
  					<th>Company</th>
  					<th>Phone Number</th>
  					<th>Website</th>
  					<th>Birthday</th>
  					<th>Gender</th>
  					<th>Bio</th>
  					
  				</tr>
  			</table>
  		<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			<table class="table" style="color: black">
  				<tr>
  					<th><?php echo e($user->getEmail()); ?></th>
  					<th><?php echo e($user->getFirstname()); ?></th>
  					<th><?php echo e($user->getLastname()); ?></th> 		
  					<th><?php echo e($user->getCompany()); ?></th>
  					<th><?php echo e($user->getPhonenumber()); ?></th>				
  					<th><?php echo e($user->getWebsite()); ?></th>
  					<th><?php echo e($user->getBirthdate()); ?></th>
  					<th><?php echo e($user->getGender()); ?></th>
  					<th><?php echo e($user->getBio()); ?></th>
  					<th><a class="btn btn-primary bold" href="<?php echo e(route('profileEdit', $user->getId())); ?>">Edit Profile</a></th>					
  				</tr>
  			</table>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		</div>
  	</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
    <script type="text/javascript">
    $(function() {
        $('.confirm').click(function() {
            return window.confirm("Are you sure?");
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>