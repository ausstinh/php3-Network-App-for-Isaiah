<?php $__env->startSection('title', 'User table Page'); ?>

<?php $__env->startSection('content'); ?>
<!-- Styles are here to override boostrap css -->
<style>
<!--
.table {

   width: auto;
}

.table th {
  height: 50px;
  font-size: 12px;
  padding: 15px;
 width: 150px;
 text-align: left;

}
.table td {
  height: 50px;
  font-size: 12px;
  padding-left: 30px;
 width: 20%;

 font-weight: bold;

}
-->
</style>
  	<div>
  		<div class="table-responsive bg-light">
  		<table class="table" style="color: black">
  				<tr style="display:inline-flex;">
  					<th class="center" >Email</th>
  					<th class="center" >First Name</th>
  					<th class="center">Last Name</th>
  					<th class="center" >Phone Number</th>
  					<th class="center" >Role</th>	
  				</tr>
  			</table>
  		<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		<?php if($user->getId() != Session::get('users_id')): ?>
  			<table class="table" style="color: black">
  				<tr style="text-align: center">
  					<td><?php echo e($user->getEmail()); ?></td>
  					<td><?php echo e($user->getFirstname()); ?></td>
  					<td><?php echo e($user->getLastname()); ?></td> 		
  					<td><?php echo e($user->getPhonenumber()); ?></td>				
  					<td><?php echo e($user->getRole()); ?></td>
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px" href="<?php echo e(route('profileEdit', $user->getId())); ?>">Edit Profile</a></td>
  					<?php if($user->getSuspend() == 0): ?>
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/suspendUser/'.$user->getId())); ?>">Suspend</a></td>
  					<?php elseif($user->getSuspend() == 1): ?>
  					<td><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/unSuspendUser/'.$user->getId())); ?>">UnSuspend</a></td>
  					<?php endif; ?>
  					<td><a class="btn btn-primary bold confirm" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/terminateUser/'.$user->getId())); ?>">Delete</a></td>
  				</tr>
  			</table>
  			<?php endif; ?>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		</div>
  	</div>
 
    <script type="text/javascript">
    $(function() {
        $('.confirm').click(function() {
            return window.confirm("Are you sure?");
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>