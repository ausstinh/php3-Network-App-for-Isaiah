<?php $__env->startSection('title', 'User table Page'); ?>

<?php $__env->startSection('content'); ?>

  	<div>
  		<div class="table-responsive bg-light">
  		<table class="table" style="color: black">
  				<tr style="display:inline-flex;">
  					<th style="width: auto">Email</th>
  					<th style="width: auto">First Name</th>
  					<th style="width: auto">Last Name</th>
  					<th style="width: auto">Company</th>
  					<th style="width: auto">Phone Number</th>
  					<th style="width: auto">Website</th>
  					<th style="width: auto">Birthday</th>
  					<th style="width: auto">Gender</th>
  					<th style="width: auto">Bio</th>
  					<th style="width: auto">Role</th>
  					
  				</tr>
  			</table>
  		<?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			<table class="table" style="color: black">
  				<tr style="text-align: center">
  					<th style="width: 10%"><?php echo e($user->getEmail()); ?></th>
  					<th><?php echo e($user->getFirstname()); ?></th>
  					<th><?php echo e($user->getLastname()); ?></th> 		
  					<th><?php echo e($user->getCompany()); ?></th>
  					<th><?php echo e($user->getPhonenumber()); ?></th>				
  					<th><?php echo e($user->getWebsite()); ?></th>
  					<th><?php echo e($user->getBirthdate()); ?></th>
  					<th><?php echo e($user->getGender()); ?></th>
  					<th><?php echo e($user->getBio()); ?></th>
  					<th><?php echo e($user->getRole()); ?></th>
  					<th><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px" href="<?php echo e(route('profileEdit', $user->getId())); ?>">Edit Profile</a></th>
  					<?php if($user->getSuspend() == 0): ?>
  					<th><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/suspendUser/'.$user->getId())); ?>">Suspend</a></th>
  					<?php elseif($user->getSuspend() == 1): ?>
  					<th><a class="btn btn-primary bold" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/unSuspendUser/'.$user->getId())); ?>">UnSuspend</a></th>
  					<?php endif; ?>
  					<th><a class="btn btn-primary bold confirm" style="width: 80px; height: 25px; font-size: 10px"  href="<?php echo e(URL::to('/terminateUser/'.$user->getId())); ?>">Delete</a></th>
  				</tr>
  			</table>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		</div>
  	</div>
 
    <script type="text/javascript">
    $(function() {
        $('.confirm').click(function() {
            return window.confirm("Are you sure?");
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>