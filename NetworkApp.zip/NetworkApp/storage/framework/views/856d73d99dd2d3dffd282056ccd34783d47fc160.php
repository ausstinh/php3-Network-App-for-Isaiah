<?php
use App\Models\UserModel;
?>

<?php $__env->startSection('title', 'ProfileEdit'); ?> 
<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<body>
	<div class="container emp-profile">
		<form method="post" action="<?php echo e(route('refurbishUser')); ?>">
			<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />
			<div class="row">
<!-- 				<div class="col-md-2"> -->
					<!-- For Later Use of profile photo
<!-- 				  <div class="col-md-2"> -->
<!--                         <div class="profile-head">   -->
                           <!-- In case we want to put somthing in the profile header -->                                                                   
<!--                         </div> -->
<!--                     </div> -->
					<div class="col-sm-3"></div>
				    <div class="col-sm-3"></div>
                    <div class="col-sm-4" style="margin-left: 80px">                
                         <input type="submit" value="Save Changes" class="btn btn-primary bold">	     
                          <a class="btn btn-primary bold" href="<?php echo e(route('profile', $model->getId())); ?>">Cancel Changes</a>                                                      
				 </div>
			</div>
			<div class="row" style="margin-top: 30px;">
				<div class="col-md-6">
					<div class="tab-content profile-tab" id="myTabContent">
						<div class="tab-pane fade show active center" id="home"
							role="tabpanel" aria-labelledby="home-tab">
							<div class="row">
								<div class="col-md-3 " style="color: Black">
									<label hidden>Id</label>
								</div>
								<div class="col-md-5 ">
									<div class="input-group form-group" style="width:300px">
										<input type="text" class="form-control bold"
											value="<?php echo e($model->getId()); ?>" name="id" hidden>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3 " style="color: Black">
									<label>Email</label>
								</div>
								<div class="col-md-5 ">
									<div class="input-group form-group" style="width:300px">
										<input type="text" class="form-control bold"
											value="<?php echo e($model->getEmail()); ?>" name="email">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>First Name</label>
								</div>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										value="<?php echo e($model->getFirstName()); ?>" name="firstname">
								</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Last Name</label>
								</div>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										value="<?php echo e($model->getLastName()); ?>" name="lastname">
								</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Phone</label>
								</div>
								<?php if($model->getPhonenumber() != null): ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										value="<?php echo e($model->getPhonenumber()); ?>" name="phonenumber">
								</div>
								</div>
								<?php else: ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										Placeholder="Insert A PhoneNumber" name="phonenumber">

								</div>
								</div>
								<?php endif; ?>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Company</label>
								</div>
								<?php if($model->getCompany() != null): ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										value="<?php echo e($model->getCompany()); ?>" name="company">
								</div>
								</div>
								<?php else: ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										Placeholder="Insert A Company" name="company">
								</div>
								</div>
								<?php endif; ?>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Website</label>
								</div>
								<?php if($model->getWebsite() != null): ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										value="<?php echo e($model->getWebsite()); ?>" name="website">
								</div>
								</div>
								<?php else: ?>
								<div class="col-md-5">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										Placeholder="Insert A Website" name="website">
								</div>
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="tab-content profile-tab" id="myTabContent">
						<div class="tab-pane fade show active center" id="home"
							role="tabpanel" aria-labelledby="home-tab">
							<div class="row">
								<div class="col-md-3 " style="color: Black">
									<label>Birth Date</label>
								</div>
								<?php if($model->getBirthdate() != null): ?>
								<div class="col-md-5 ">
								<div class="input-group form-group" style="width:300px">
										<input type="text" class="form-control bold"
										value="<?php echo e($model->getBirthdate()); ?>" name="birthdate">
								</div>
								</div>
								<?php else: ?>
								<div class="col-md-5 ">
								<div class="input-group form-group" style="width:300px">
									<input type="text" class="form-control bold"
										Placeholder="Insert a Birth Date" name="birthdate">
								</div>
								</div>
								<?php endif; ?>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Gender</label>
								</div>
								<?php if($model->getGender() == 0): ?>
								<div class="col-md-3">
								<div class="input-group form-group" style="width:300px">
									<select name="gender" class="form-control bold">    
                                      <option class="bold" value=0 selected>Male</option>
                                      <option class="bold" value=1>Female</option>
                                    </select>
                   		     </div>
								</div>
								<?php else: ?>
								<div class="col-md-3">
								<div class="input-group form-group">
									<select name="gender" class="form-control bold">
                                      <option value="">Select...</option>
                                      <option class="bold" value=0>Male</option>
                                      <option class="bold" value=1 selected>Female</option>
                                    </select>
                     			   </div>
								</div>
								<?php endif; ?>
							</div>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Bio</label>
								</div>
								<?php if($model->getBio() != null): ?>
								<div class="col-md-6">
								<div class="input-group form-group" style="width:300px">
									<textarea cols="50" id="bio" class="bold" name="bio"  rows="5"><?php echo e($model->getBio()); ?></textarea>
								</div>
								</div>
								<?php else: ?>
								<div class="col-md-6">
								<div class="input-group form-group" style="width:300px">
									<textarea cols="50" class="bold" name="bio" Placeholder="Insert a New Bio" rows="5"></textarea>
								</div>
								</div>
								<?php endif; ?>
							</div>
							<?php if(Session::get('role') == 2): ?>
							<div class="row">
								<div class="col-md-3" style="color: Black">
									<label>Role</label>
								</div>	
								<div class="col-md-3">
								<div class="input-group form-group" style="width:300px">
									<select name="role" class="form-control bold">  
									<?php if($model->getRole() == 0): ?>
									<option class="bold" value="0" selected>Default</option> 
									<option class="bold" value=1>Moderator</option>
                                    <option class="bold" value=2>Administator</option>
									<?php elseif($model->getRole() == 1): ?>
									 <option class="bold" value=0>Default</option>
								    <option class="bold" value=1 selected>Moderator</option> 
								    <option class="bold" value=2>Administator</option>
                                    <?php elseif($model->getRole() == 2): ?>
                                    <option class="bold" value=0>Default</option>
								    <option class="bold" value=1>Moderator</option> 
                                    <option class="bold" value=2 selected>Administator</option>
                                    <?php endif; ?>
                                    </select>
                   		         </div>
								</div>
								<?php endif; ?>
							</div>
				</div>
			</div>
		</form>
	</div>
	</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>