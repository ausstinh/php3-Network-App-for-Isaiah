	

<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
 <!-- Styles -->
        <style>
        <?php include 'public/css/styles.css'; ?>
        </style>
<div class="flex-center position-ref full-height">
	<div class="content" style="padding-bottom: 300px">
		<div class="title m-b-md"></div>
		<h2 style="font-weight: 700">You are suspended</h2><br>
		<a href="javascript:history.back()" style="font-weight: 700; color:white">Go Back</a>
		
	</div>
</div>
</html>
